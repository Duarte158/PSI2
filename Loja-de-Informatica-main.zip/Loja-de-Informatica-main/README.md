<h1>Credenciais para acesso ao Projeto</h1>

<h2>Admin</h2>

<p>Utilizador: daurte</p>

<p>Senha: duarte321</p>

<h2>Funcionario</h2>

<p>Utilizador: funcionario</p>

<p>Senha: funcionario321</p>

<h2>Cliente</h2>

<p>Utilizador: cliente</p>

<p>Senha: cliente321</p> 