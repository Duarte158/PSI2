<?php

return [

    'db' => [
        'class' => \yii\db\Connection::class,
        'dsn' => 'mysql:host=localhost;dbname=lojadeinformatica',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
    ],

];
