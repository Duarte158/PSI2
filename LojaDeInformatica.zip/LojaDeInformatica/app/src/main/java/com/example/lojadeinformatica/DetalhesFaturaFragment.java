package com.example.lojadeinformatica;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.lojadeinformatica.listeners.FaturaListener;
import com.example.lojadeinformatica.listeners.FaturasListener;
import com.example.lojadeinformatica.modelo.Carrinho;
import com.example.lojadeinformatica.modelo.Fatura;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;

import java.util.ArrayList;

public class DetalhesFaturaFragment extends Fragment {
    private TextView tvData, tvValorTotal, tvEstado, tvFaturaId;

    public DetalhesFaturaFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_lista_fatura, container, false);

        tvData = view.findViewById(R.id.tvData);
        tvValorTotal = view.findViewById(R.id.tvValorTotal);
        tvEstado = view.findViewById(R.id.tvEstado);
        tvFaturaId = view.findViewById(R.id.tvFaturaId);

        carregarFatura();
        return view;
    }

    private void carregarFatura() {
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        String role = sharedPreferences.getString("ROLE", "");
        int userId = sharedPreferences.getInt("ID_USER", 0);

        // Se o papel for "cliente", carregamos as faturas do cliente específico
        if ("cliente".equals(role)) {
            // Chama o método com o listener adequado
            SingletonGestorApp.getInstance(getContext()).getFaturasClienteAPI(userId, getContext(), new FaturasListener() {
                @Override
                public void onRefreshListaFaturas(ArrayList<Fatura> faturas) {
                    // Verificar se as faturas são não nulas e não estão vazias
                    if (faturas != null && !faturas.isEmpty()) {
                        // Exemplo: Pega a primeira fatura da lista
                        Fatura fatura = faturas.get(0);

                        // Atualiza os TextViews com os dados da fatura e do carrinho associado
                        tvData.setText(fatura.getData());
                        if (fatura.getCarrinho() != null) {
                            Carrinho carrinho = fatura.getCarrinho();
                            tvValorTotal.setText(String.valueOf(carrinho.getValorTotal()));
                            tvEstado.setText(carrinho.getEstado());
                            tvFaturaId.setText(String.valueOf(carrinho.getUser_id()));
                        } else {
                            // Caso o carrinho não esteja disponível
                            tvValorTotal.setText("N/A");
                            tvEstado.setText("N/A");
                            tvFaturaId.setText("N/A");
                        }
                    } else {
                        // Caso não haja faturas disponíveis
                        tvData.setText("Sem faturas");
                        tvValorTotal.setText("N/A");
                        tvEstado.setText("N/A");
                        tvFaturaId.setText("N/A");
                    }
                }
            });
        } else {
            // Caso seja outro papel, carregue todas as faturas (para administradores ou outros papéis)
            SingletonGestorApp.getInstance(getContext()).getAllFaturasAPI(getContext());
        }
    }



}
