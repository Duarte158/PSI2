package com.example.lojadeinformatica.listeners;

public interface CarrinhoListener {
    void onRefreshDetalhes(int op);
}

