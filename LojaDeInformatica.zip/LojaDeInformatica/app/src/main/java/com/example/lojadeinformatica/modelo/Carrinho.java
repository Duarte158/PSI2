package com.example.lojadeinformatica.modelo;

import java.io.Serializable;

public class Carrinho  implements Serializable {
    private int id;
    private String data;
    private double valorTotal;
    private String estado;
    private double valorIva;
    private int user_id;

    // Construtor
    public Carrinho(int id, String data, double valorTotal, String estado, double valorIva, int user_id ) {
        this.id = id;
        this.data = data;
        this.valorTotal = valorTotal;
        this.estado = estado;
        this.valorIva = valorIva;
        this.user_id = user_id;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getValorIva() {
        return valorIva;
    }

    public void setValorIva(double valorIva) {
        this.valorIva = valorIva;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }


}
