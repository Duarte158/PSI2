package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Favorito;
import java.util.List;

public interface FavoritosListener {
    void onFavoritosLoaded(List<Favorito> favoritos);
}