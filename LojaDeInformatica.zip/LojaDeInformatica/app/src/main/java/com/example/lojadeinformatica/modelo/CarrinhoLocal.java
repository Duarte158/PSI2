package com.example.lojadeinformatica.modelo;

import com.example.lojadeinformatica.modelo.Artigo;

import java.util.ArrayList;
import java.util.List;

public class CarrinhoLocal {
    private List<Artigo> artigosNoCarrinho;

    public CarrinhoLocal() {
        this.artigosNoCarrinho = new ArrayList<>();
    }

    public void adicionarArtigo(Artigo artigo) {
        artigosNoCarrinho.add(artigo);
    }

    public void removerArtigo(Artigo artigo) {
        artigosNoCarrinho.remove(artigo);
    }

    public List<Artigo> getArtigosNoCarrinho() {
        return artigosNoCarrinho;
    }

    public double calcularValorTotal() {
        double valorTotal = 0;
        for (Artigo artigo : artigosNoCarrinho) {
            valorTotal += artigo.getPrecoFinal();
        }
        return valorTotal;
    }

    // Outras lógicas que você precisar, como calcular valor total com IVA, etc.
}
