package com.example.lojadeinformatica.listeners;

public interface CategoriaListener {
    void onRefreshDetalhes(int op);

}
