package com.example.lojadeinformatica;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lojadeinformatica.adaptadores.ListaCarrinhosAdaptador;
import com.example.lojadeinformatica.listeners.CarrinhosListener;
import com.example.lojadeinformatica.modelo.Carrinho;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class CriarCarrinhoFragment extends Fragment implements CarrinhosListener {

    private ListView lvLista;
    private ArrayList<Carrinho> carrinhos;
    private SearchView searchView;
    private FloatingActionButton fabLista;
    public static final int ACT_DETALHES = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Definir a vista
        onRefreshListaCarrinhos(carrinhos);
        View view = inflater.inflate(R.layout.fragment_lista, container, false);
        setHasOptionsMenu(true);
        lvLista = view.findViewById(R.id.lvLista);
        fabLista = view.findViewById(R.id.fabLista);
        //Editar Pedido se selecionar um pedido
        lvLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(getContext(), EditarCarrinhoActivity.class);
                intent.putExtra("ID_CARRINHO", (int) id);
                startActivityForResult(intent, ACT_DETALHES);
            }
        });

        //criar novo pedido
        fabLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), CriarCarrinhoActivity.class);
                startActivityForResult(intent, ACT_DETALHES);
            }
        });
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("USER_ID", 0);
        //carregar pedidos em processamento
        SingletonGestorApp.getInstance(getContext()).setCarrinhosListener(this);
        SingletonGestorApp.getInstance(getContext()).getCarrinhosAtivosAPI(userId, getContext());
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        if (resultCode == Activity.RESULT_OK && requestCode == ACT_DETALHES) {
            SharedPreferences sharedPreferences = getContext().getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
            int userId = sharedPreferences.getInt("USER_ID", 0);
            SingletonGestorApp.getInstance(getContext()).getCarrinhosAtivosAPI(userId, getContext());
        }
    }


    @Override
    public void onResume() {
        if (searchView != null) {
            searchView.onActionViewCollapsed();
        }
        super.onResume();
    }

    @Override
    public void onRefreshListaCarrinhos(ArrayList<Carrinho> listaCarrinhos) {
        if (listaCarrinhos != null) {
            lvLista.setAdapter(new ListaCarrinhosAdaptador(getContext(), listaCarrinhos));
        }
    }

}
