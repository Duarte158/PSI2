package com.example.lojadeinformatica.utils;

import com.example.lojadeinformatica.modelo.Artigo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ArtigoJsonParser {

    // Método para parse de uma lista de artigos a partir de um JSONArray
    public static ArrayList<Artigo> parserJsonArtigos(JSONArray response) {
        ArrayList<Artigo> artigos = new ArrayList<>();
        try {
            for (int i = 0; i < response.length(); i++) {
                JSONObject artigoJson = (JSONObject) response.get(i);

                // Extração dos campos
                int Id = artigoJson.getInt("Id");
                String descricao = artigoJson.getString("descricao");
                int precoUni = artigoJson.getInt("precoUni");
                int precoFinal = artigoJson.getInt("precoFinal");
                int stock = artigoJson.getInt("stock");
                int categoriaId = artigoJson.getInt("categoria_id");
                int ivasId = artigoJson.getInt("iva_id");
                int marcaId = artigoJson.getInt("marca_id"); // Marca ID
                int unidadeId = artigoJson.getInt("unidade_id"); // Unidade ID
                String nome = artigoJson.getString("nome"); // Nome
                String referencia = artigoJson.getString("referencia"); // Referência
                String imagem = artigoJson.getString("imagem"); // Imagem
                boolean destaque = artigoJson.getInt("destaque") == 1; // Destaque (Booleano)

                // Criação do objeto Artigo
                Artigo artigo = new Artigo(
                        Id,                // ID
                        precoUni,          // Preço Unitário
                        precoFinal,        // Preço Final
                        stock,             // Stock
                        categoriaId,       // Categoria ID
                        ivasId,            // IVA ID
                        unidadeId,         // Unidade ID
                        marcaId,           // Marca ID
                        descricao,         // Descrição
                        imagem,            // Imagem
                        referencia,        // Referência
                        nome,              // Nome
                        destaque           // Destaque (Booleano)
                );
                artigos.add(artigo);
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return artigos;
    }

    // Método para parse de um único artigo a partir de uma string JSON
    public static Artigo parserJsonArtigo(String response) {
        try {
            JSONObject jsonArtigo = new JSONObject(response);

            // Extração dos campos
            int Id = jsonArtigo.optInt("id", -1);
            String descricao = jsonArtigo.optString("descricao", "");
            float precoUni = (float) jsonArtigo.optDouble("preco", 0.0);
            float precoFinal = (float) jsonArtigo.optDouble("precoFinal", 0.0);
            int stock = jsonArtigo.optInt("stock", 0);
            int categoriaId = jsonArtigo.optInt("categoria_id", -1);
            int IvaId = jsonArtigo.optInt("iva_id", -1);
            int marcaId = jsonArtigo.optInt("marca_id", -1);  // Marca ID
            int unidadeId = jsonArtigo.optInt("unidade_id", -1); // Unidade ID
            String nome = jsonArtigo.optString("nome", "");
            String referencia = jsonArtigo.optString("referencia", "");
            String imagem = jsonArtigo.optString("imagem", "");
            boolean destaque = jsonArtigo.optInt("destaque", 0) == 1;  // Destaque (Booleano)

            // Criação do objeto Artigo
            Artigo artigo = new Artigo(
                    Id,                // ID
                    precoUni,          // Preço Unitário
                    precoFinal,        // Preço Final
                    stock,             // Stock
                    categoriaId,       // Categoria ID
                    IvaId,            // IVA ID
                    unidadeId,         // Unidade ID
                    marcaId,           // Marca ID
                    descricao,         // Descrição
                    imagem,            // Imagem
                    referencia,        // Referência
                    nome,              // Nome
                    destaque           // Destaque (Booleano)
            );



            return artigo;

        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Método para converter um Artigo para JSON
    public static String artigoParaJson(Artigo artigo) {
        JSONObject jsonArtigo = new JSONObject();
        try {
            jsonArtigo.put("Id", artigo.getId());
            jsonArtigo.put("descricao", artigo.getDescricao());
            jsonArtigo.put("precoUni", artigo.getPrecoUni());
            jsonArtigo.put("precoFinal", artigo.getPrecoFinal()); // Preço Final
            jsonArtigo.put("stock", artigo.getStock());
            jsonArtigo.put("categoria_id", artigo.getCategoriaId());
            jsonArtigo.put("iva_id", artigo.getIvasId());
            jsonArtigo.put("marca_id", artigo.getMarcaId()); // Marca ID
            jsonArtigo.put("unidade_id", artigo.getUnidadeId()); // Unidade ID
            jsonArtigo.put("nome", artigo.getNome()); // Nome
            jsonArtigo.put("referencia", artigo.getReferencia()); // Referência
            jsonArtigo.put("imagem", artigo.getImagem()); // Imagem
            jsonArtigo.put("destaque", artigo.isDestaque() ? 1 : 0); // Destaque (Booleano)

            // Adicionar outros campos, se necessário

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArtigo.toString();
    }
}
