package com.example.lojadeinformatica;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import androidx.fragment.app.Fragment;

import com.example.lojadeinformatica.adaptadores.FavoritosAdapter;
import com.example.lojadeinformatica.listeners.FavoritosListener;
import com.example.lojadeinformatica.modelo.Favorito;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import java.util.List;

public class FavoritosFragment extends Fragment implements FavoritosListener {

    private ListView listViewFavoritos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_favoritos, container, false);
        listViewFavoritos = rootView.findViewById(R.id.listViewFavoritos);

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("USER_PREFS", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId != -1) {
            Log.d("FavoritosFragment", "User ID: " + userId);
            SingletonGestorApp.getInstance(getContext()).carregarFavoritos(userId, this);
        } else {
            Log.d("FavoritosFragment", "User ID not found");
        }

        return rootView;
    }

    @Override
    public void onFavoritosLoaded(List<Favorito> favoritos) {
        if (favoritos != null && !favoritos.isEmpty()) {
            Log.d("FavoritosFragment", "Favoritos loaded: " + favoritos.size());
            FavoritosAdapter favoritosAdapter = new FavoritosAdapter(getContext(), favoritos);
            listViewFavoritos.setAdapter(favoritosAdapter);
        } else {
            Log.d("FavoritosFragment", "No favoritos found");
        }
    }
}
