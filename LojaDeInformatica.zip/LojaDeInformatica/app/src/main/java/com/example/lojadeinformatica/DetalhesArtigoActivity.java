package com.example.lojadeinformatica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.CheckBox;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.lojadeinformatica.listeners.ArtigoListener;
import com.example.lojadeinformatica.modelo.Artigo;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DetalhesArtigoActivity extends AppCompatActivity implements ArtigoListener {

    public static final String ID_ARTIGO = "id";
    private final int MIN_CHAR = 3, MIN_NUMEROS = 1;
    private EditText etReferencia, etPreco, etPrecoFinal, etStock, etDescricao, etCategoria, etIva, etMarca, etUnidade, etNome;
    private FloatingActionButton fabGuardar;
    private Button btnFavoritos;
    private ImageView imgImagem;
    private Artigo artigo;
    private CheckBox cbDestaque;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_artigo);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Exibir o ícone de "voltar"
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Detalhes Artigo");

        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        String role = sharedPreferences.getString("ROLE", "");

        // Inicialização dos campos
        etReferencia = findViewById(R.id.etReferencia);
        etPreco = findViewById(R.id.etPreco);
        etPrecoFinal = findViewById(R.id.etPrecoFinal);
        etStock = findViewById(R.id.etStock);
        etDescricao = findViewById(R.id.etDescricao);
        etCategoria = findViewById(R.id.etCategoria);
        etIva = findViewById(R.id.etIva);
        etMarca = findViewById(R.id.etMarca);
        etUnidade = findViewById(R.id.etUnidade);
        etNome = findViewById(R.id.etNome);
        imgImagem = findViewById(R.id.imgImagem);
        cbDestaque = findViewById(R.id.cbDestaque);
        fabGuardar = findViewById(R.id.fabGuardar);
        btnFavoritos = findViewById(R.id.btnAdicionarFavoritos);

        SingletonGestorApp.getInstance(getApplicationContext()).setArtigoListener(this);

        int id = getIntent().getIntExtra(ID_ARTIGO, 0);
        if (id != 0) {
            artigo = SingletonGestorApp.getInstance(getApplicationContext()).getArtigo(id);
            if (artigo != null) {
                carregarArtigo();
                fabGuardar.setImageResource(R.drawable.ic_guardar);
            } else {
                finish(); // Fecha se o artigo não for encontrado
            }
        } else {
            setTitle("Adicionar Artigo");
            fabGuardar.setImageResource(R.drawable.ic_adicionar);
        }

        // Configuração de visibilidade do FAB de edição para clientes
        if ("cliente".equals(role)) {
            desabilitarCampos();
            fabGuardar.setVisibility(View.GONE);
        } else {
            fabGuardar.setVisibility(View.VISIBLE);
            fabGuardar.setOnClickListener(v -> {
                if (artigo != null) { // Artigo existente
                    if (isArtigoValido()) {
                        artigo.setReferencia(etReferencia.getText().toString());
                        artigo.setPrecoFinal(Float.parseFloat(etPrecoFinal.getText().toString()));
                        artigo.setPrecoUni(Float.parseFloat(etPreco.getText().toString()));
                        artigo.setStock(Integer.parseInt(etStock.getText().toString()));
                        artigo.setCategoriaId(Integer.parseInt(etCategoria.getText().toString()));
                        artigo.setIvasId(Integer.parseInt(etIva.getText().toString()));
                        artigo.setMarcaId(Integer.parseInt(etMarca.getText().toString()));
                        artigo.setUnidadeId(Integer.parseInt(etUnidade.getText().toString()));
                        artigo.setDescricao(etDescricao.getText().toString());
                        artigo.setNome(etNome.getText().toString());
                        artigo.setImagem(imgImagem.toString());
                        artigo.setDestaque(cbDestaque.isChecked());

                        SingletonGestorApp.getInstance(getApplicationContext()).editarArtigoAPI(artigo, getApplicationContext());
                    }
                } else { // Novo artigo
                    if (isArtigoValido()) {
                        artigo = new Artigo(
                                0,
                                Float.parseFloat(etPreco.getText().toString()),
                                Float.parseFloat(etPrecoFinal.getText().toString()),
                                Integer.parseInt(etStock.getText().toString()),
                                Integer.parseInt(etCategoria.getText().toString()),
                                Integer.parseInt(etIva.getText().toString()),
                                Integer.parseInt(etUnidade.getText().toString()),
                                Integer.parseInt(etMarca.getText().toString()),
                                etDescricao.getText().toString(),
                                imgImagem.toString(),
                                etReferencia.getText().toString(),
                                etNome.getText().toString(),
                                cbDestaque.isChecked()
                        );
                        SingletonGestorApp.getInstance(getApplicationContext()).adicionarArtigoAPI(artigo, getApplicationContext());
                    }
                }
            });
        }

        // Configurar o botão de adicionar aos favoritos (visível para clientes)
        btnFavoritos.setOnClickListener(v -> {
            // Obter o ID do usuário dos SharedPreferences
            SharedPreferences sp = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
            int userId = sp.getInt("ID_USER", 0);
            if (userId == 0) {
                Toast.makeText(DetalhesArtigoActivity.this, "Você precisa estar logado para adicionar aos favoritos", Toast.LENGTH_SHORT).show();
                return;
            }
            if (artigo != null) {
                // Chama o método para adicionar o artigo aos favoritos
                SingletonGestorApp.getInstance(getApplicationContext()).adicionarFavoritoAPI(userId, artigo.getId(), getApplicationContext());
                Toast.makeText(DetalhesArtigoActivity.this, "Artigo adicionado aos favoritos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void desabilitarCampos() {
        etReferencia.setKeyListener(null);
        etPreco.setKeyListener(null);
        etPrecoFinal.setKeyListener(null);
        etStock.setKeyListener(null);
        etDescricao.setKeyListener(null);
        etCategoria.setKeyListener(null);
        etIva.setKeyListener(null);
        etMarca.setKeyListener(null);
        etUnidade.setKeyListener(null);
        etNome.setKeyListener(null);
        cbDestaque.setEnabled(false);
    }

    private boolean isArtigoValido() {
        String referencia = etReferencia.getText().toString();
        String preco = etPreco.getText().toString();
        String precoFinal = etPrecoFinal.getText().toString();
        String stock = etStock.getText().toString();
        String categoria = etCategoria.getText().toString();
        String iva = etIva.getText().toString();
        String descricao = etDescricao.getText().toString();
        String nome = etNome.getText().toString();

        if (referencia.length() < MIN_NUMEROS) {
            etReferencia.setError("Referência inválida");
            return false;
        }
        if (preco.length() < MIN_NUMEROS) {
            etPreco.setError("Preço inválido");
            return false;
        }
        if (precoFinal.length() < MIN_NUMEROS) {
            etPrecoFinal.setError("Preço final inválido");
            return false;
        }
        if (stock.length() < MIN_NUMEROS) {
            etStock.setError("Stock inválido");
            return false;
        }
        if (descricao.length() < MIN_CHAR) {
            etDescricao.setError("Descrição inválida");
            return false;
        }
        if (categoria.length() < MIN_NUMEROS) {
            etCategoria.setError("Id Categoria inválido");
            return false;
        }
        if (iva.length() < MIN_NUMEROS) {
            etIva.setError("Id IVA inválido");
            return false;
        }
        if (nome.length() < MIN_CHAR) {
            etNome.setError("Nome inválido");
            return false;
        }
        return true;
    }

    private void carregarArtigo() {
        setTitle("Detalhes: " + artigo.getDescricao());
        etReferencia.setText(artigo.getReferencia());
        etPreco.setText(String.valueOf(artigo.getPrecoUni()));
        etPrecoFinal.setText(String.valueOf(artigo.getPrecoFinal()));
        etStock.setText(String.valueOf(artigo.getStock()));
        etCategoria.setText(String.valueOf(artigo.getCategoriaId()));
        etIva.setText(String.valueOf(artigo.getIvasId()));
        etMarca.setText(String.valueOf(artigo.getMarcaId()));
        etUnidade.setText(String.valueOf(artigo.getUnidadeId()));
        etNome.setText(artigo.getNome());
        etDescricao.setText(artigo.getDescricao());
        cbDestaque.setChecked(artigo.isDestaque());

        Glide.with(getApplicationContext())
                .load(artigo.getImagem())
                .placeholder(R.drawable.logo)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(imgImagem);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        String role = sharedPreferences.getString("ROLE", "");

        if (!"cliente".equals(role)) {
            if (artigo != null) {
                getMenuInflater().inflate(R.menu.menu_remover, menu);
                return true;
            }
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itemRemover) {
            dialogRemover();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogRemover() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remover Artigo")
                .setMessage("Tem a certeza que pretende remover o artigo?")
                .setPositiveButton(android.R.string.yes, (dialogInterface, i) -> {
                    SingletonGestorApp.getInstance(getApplicationContext()).removerArtigoAPI(artigo, getApplicationContext());
                })
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }

    @Override
    public void onRefreshDetalhes(int op) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}