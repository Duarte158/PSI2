package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Fatura;

import java.util.ArrayList;

public interface FaturasListener {
    void onRefreshListaFaturas(ArrayList<Fatura> listaFaturas);
}

