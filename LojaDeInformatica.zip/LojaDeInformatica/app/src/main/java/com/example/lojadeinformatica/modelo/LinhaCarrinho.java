package com.example.lojadeinformatica.modelo;

public class LinhaCarrinho {
    private int id;
    private int quantidade;
    private double valor; // Valor total da linha
    private int carrinho_id;
    private int artigo_id;
    private String nomeArtigo; // Adicionado para armazenar o nome do artigo

    // Construtor
    public LinhaCarrinho(int id, int quantidade, double valor, int carrinho_id, int artigo_id, String nomeArtigo) {
        this.id = id;
        this.quantidade = quantidade;
        this.valor = valor;
        this.carrinho_id = carrinho_id;
        this.artigo_id = artigo_id;
        this.nomeArtigo = nomeArtigo;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getCarrinho_id() {
        return carrinho_id;
    }

    public void setCarrinho_id(int carrinho_id) {
        this.carrinho_id = carrinho_id;
    }

    public int getArtigo_id() {
        return artigo_id;
    }

    public void setArtigo_id(int artigo_id) {
        this.artigo_id = artigo_id;
    }

    public String getNomeArtigo() {
        return nomeArtigo;
    }

    public void setNomeArtigo(String nomeArtigo) {
        this.nomeArtigo = nomeArtigo;
    }
}