package com.example.lojadeinformatica;


import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.lojadeinformatica.adaptadores.LinhasCarrinhoAdapter;
import com.example.lojadeinformatica.listeners.LinhasCarrinhoListener;
import com.example.lojadeinformatica.modelo.Artigo;
import com.example.lojadeinformatica.modelo.LinhaCarrinho;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class EditarCarrinhoActivity extends AppCompatActivity implements LinhasCarrinhoListener {

    private ListView lvLinhascarrinho;
    private LinhaCarrinho linhaCarrinho;
    private EditText etQuantidade;
    private Spinner spArtigo;
    int carrinho_id;
    private ArrayList<LinhaCarrinho> linhaCarrinhos;
    private SearchView searchView;
    private FloatingActionButton fabLista;
    public static final int ACT_DETALHES = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_linha_carrinho);

        // Inicializa os elementos da interface
        lvLinhascarrinho = findViewById(R.id.lvLinhascarrinho);
        etQuantidade = findViewById(R.id.etQuantidade);
        spArtigo = findViewById(R.id.spArtigo);

        // Inicializa o Spinner com dados de teste (você pode substituir isso pela sua lógica)
        ArrayList<Artigo> teste = SingletonGestorApp.getInstance(getApplicationContext()).getArtigosBD();
        ArrayAdapter<Artigo> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, teste);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spArtigo.setAdapter(arrayAdapter);

        // Configura o clique na lista
        lvLinhascarrinho.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                LinhaCarrinho linhaCarrinho = SingletonGestorApp.getInstance(getApplicationContext()).getLinhaCarrinho((int) id);
                // Implemente o que você deseja fazer com a linhaCarrinho selecionada
            }
        });

        // Obtém o ID do carrinho da Intent
        carrinho_id = getIntent().getIntExtra("ID_CARRINHO", 0);

        // Configura o Listener e obtém as linhas de carrinho da API
        SingletonGestorApp.getInstance(getApplicationContext()).setLinhasCarrinhoListener(this);
    }

    @Override
    public void onResume() {
        if (searchView != null) {
            searchView.onActionViewCollapsed();
        }
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("USER_ID", 0);
        SingletonGestorApp.getInstance(getApplicationContext()).getCarrinhosAtivosAPI(userId, getApplicationContext());
        finish();
    }

    //Guardar linhas de pedido e atualizar dinamicamente
    public void onClickGuardar(View view) {
        EditText etQuantidade = findViewById(R.id.etQuantidade);
        Spinner spArtigo = findViewById(R.id.spArtigo);

        if (etQuantidade != null && spArtigo != null) {
            String quantidadeText = etQuantidade.getText().toString();

            if (TextUtils.isDigitsOnly(quantidadeText)) {
                int quantidade = Integer.parseInt(quantidadeText);

                // Obtem o objeto Artigo selecionado
                Artigo artigoSelecionado = (Artigo) spArtigo.getSelectedItem();

                if (artigoSelecionado != null) {
                    int idartigo = artigoSelecionado.getId();

                    Log.d("DEBUG", "onClickGuardar: " + idartigo + "  " + carrinho_id + "  " + quantidade);

                    SingletonGestorApp gestorApp = SingletonGestorApp.getInstance(getApplicationContext());

                    if (gestorApp != null) {
                        gestorApp.adicionarLinhaCarrinhoAPI(idartigo, carrinho_id, quantidade, getApplicationContext());
                    } else {
                        Log.e("ERROR", "SingletonGestorApp é nulo.");
                    }
                } else {
                    Log.e("ERROR", "Artigo selecionado é nulo.");
                }
            } else {
                // Trate o caso em que o valor não é um número válido.
                Toast.makeText(this, "Quantidade inválida", Toast.LENGTH_SHORT).show();
            }
        } else {
            Log.e("ERROR", "etQuantidade ou spArtigo são nulos.");
        }
    }

    private void dialogRemover(LinhaCarrinho linhaCarrinho) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remover Linha do Carrinho")
                .setMessage("Tem a certeza que pretende remover a linha do carrinho?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SingletonGestorApp.getInstance(getApplicationContext()).removerLinhaCarrinhoAPI(linhaCarrinho, getApplicationContext());
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Nao fazer nada
                    }
                })
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }

    @Override
    public void onRefreshListaLinhasCarrinho(ArrayList<LinhaCarrinho> listaLinhasCarrinho) {
        if (listaLinhasCarrinho != null) {
            lvLinhascarrinho.setAdapter(new LinhasCarrinhoAdapter(getApplicationContext(), listaLinhasCarrinho));
        }
    }

}
