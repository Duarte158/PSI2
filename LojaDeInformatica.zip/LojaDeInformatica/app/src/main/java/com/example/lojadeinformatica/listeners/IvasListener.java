package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Iva;

import java.util.ArrayList;

public interface IvasListener {
    void onRefreshListaIvas(ArrayList<Iva> listaIvas);

}
