package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Fatura;
import com.example.lojadeinformatica.modelo.LinhaCarrinho;

import java.util.ArrayList;

public interface LinhasCarrinhoFaturaListener{


    void onLinhasCarrinhoReceived(ArrayList<LinhaCarrinho> linhasCarrinho);
    void onError(String error);
}