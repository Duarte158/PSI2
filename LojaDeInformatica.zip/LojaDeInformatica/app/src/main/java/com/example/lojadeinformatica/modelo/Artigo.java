package com.example.lojadeinformatica.modelo;

public class Artigo {

    public int Id, stock, categoria_id, ivas_id, marca_id, unidade_id;
    public float precoUni, precoFinal;
    public boolean destaque;
    public String referencia, descricao, imagem, nome;

    // Construtor com todos os campos
    public Artigo(int Id, float precoUni, float precoFinal, int stock, int categoria_id, int ivas_id,
                  int unidade_id, int marca_id, String descricao, String imagem, String referencia,
                  String nome, Boolean destaque) {
        this.Id = Id;
        this.referencia = referencia;
        this.stock = stock;
        this.descricao = descricao;
        this.descricao = descricao;
        this.categoria_id = categoria_id;
        this.ivas_id = ivas_id;
        this.imagem = imagem;
        this.marca_id = marca_id;
        this.unidade_id = unidade_id;
        this.precoUni = precoUni;
        this.precoFinal = precoFinal;
        this.nome = nome;
        this.destaque = destaque;
    }

    // Getters e Setters

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        this.Id = id;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public float getPrecoUni() {
        return precoUni;
    }

    public void setPrecoUni(float precoUni) {
        this.precoUni = precoUni;
    }

    public float getPrecoFinal() {
        return precoFinal;
    }

    public void setPrecoFinal(float precoFinal) {
        this.precoFinal = precoFinal;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getCategoriaId() {
        return categoria_id;
    }

    public void setCategoriaId(int categoria_id) {
        this.categoria_id = categoria_id;
    }

    public int getIvasId() {
        return ivas_id;
    }

    public void setIvasId(int ivas_id) {
        this.ivas_id = ivas_id;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isDestaque() {
        return destaque;
    }

    public void setDestaque(boolean destaque) {
        this.destaque = destaque;
    }

    public int getMarcaId() {
        return marca_id;
    }

    public void setMarcaId(int marca_id) {
        this.marca_id = marca_id;
    }

    public int getUnidadeId() {
        return unidade_id;
    }

    public void setUnidadeId(int unidade_id) {
        this.unidade_id = unidade_id;
    }

    @Override
    public String toString() {
        return "Artigo{" +
                "id=" + Id +
                ", nome='" + nome + '\'' +
                ", descricao='" + descricao + '\'' +
                ", precoUni=" + precoUni +
                ", stock=" + stock +
                ", categoria_id=" + categoria_id +
                ", ivas_id=" + ivas_id +
                ", destaque=" + destaque +
                ", referencia='" + referencia + '\'' +
                ", imagem='" + imagem + '\'' +
                ", precoFinal=" + precoFinal +
                ", marca_id=" + marca_id +
                ", unidade_id=" + unidade_id +
                '}';
    }
}
