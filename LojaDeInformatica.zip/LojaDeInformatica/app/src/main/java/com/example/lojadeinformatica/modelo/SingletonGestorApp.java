package com.example.lojadeinformatica.modelo;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.lojadeinformatica.listeners.CountListener;
import com.example.lojadeinformatica.listeners.FavoritosListener;
import com.example.lojadeinformatica.listeners.LinhasCarrinhoFaturaListener;
import com.example.lojadeinformatica.MainActivity;
import com.example.lojadeinformatica.listeners.ArtigoListener;
import com.example.lojadeinformatica.listeners.ArtigosListener;
import com.example.lojadeinformatica.listeners.CarrinhoAtivoListener;
import com.example.lojadeinformatica.listeners.CarrinhoListener;
import com.example.lojadeinformatica.listeners.CarrinhosListener;
import com.example.lojadeinformatica.listeners.CategoriaListener;
import com.example.lojadeinformatica.listeners.CategoriasListener;
import com.example.lojadeinformatica.listeners.FaturaListener;
import com.example.lojadeinformatica.listeners.FaturasListener;
import com.example.lojadeinformatica.listeners.IvaListener;
import com.example.lojadeinformatica.listeners.IvasListener;
import com.example.lojadeinformatica.listeners.LinhaCarrinhoListener;
import com.example.lojadeinformatica.listeners.LinhasCarrinhoListener;
import com.example.lojadeinformatica.listeners.LoginListener;
import com.example.lojadeinformatica.utils.ArtigoJsonParser;
import com.example.lojadeinformatica.utils.CarrinhoJsonParser;
import com.example.lojadeinformatica.utils.CategoriaJsonParser;
import com.example.lojadeinformatica.utils.FaturaJsonParser;
import com.example.lojadeinformatica.utils.IvaJsonParser;
import com.example.lojadeinformatica.utils.LinhaCarrinhoJsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class SingletonGestorApp {
    private ArrayList<Artigo> artigos;
    private ArrayList<Carrinho> carrinhos;
    private ArrayList<Categoria> categorias;
    private ArrayList<Fatura> faturas;
    private ArrayList<Iva> ivas;
    private ArrayList<LinhaCarrinho> linhaCarrinhos;
    private static SingletonGestorApp instance = null;
    private ArtigosDBHelper artigoBD = null;
    private static RequestQueue volleyQueue = null;
    private String UrlAPI = null;
    private String TOKEN = null;
    private ArtigosListener artigosListener;
    private ArtigoListener artigoListener;
    private CategoriasListener categoriasListener;
    private CategoriaListener categoriaListener;
    private CarrinhosListener carrinhosListener;
    private CarrinhoListener carrinhoListener;
    private CarrinhoAtivoListener carrinhoAtivoListener;

    private FaturasListener faturasListener;
    private FaturaListener faturaListener;

    private IvasListener ivasListener;
    private IvaListener ivaListener;


    private CountListener countListener;
    private LinhasCarrinhoListener linhasCarrinhoListener;
    private LinhaCarrinhoListener linhaCarrinhoListener;

    private LoginListener loginListener;
    private SharedPreferences sharedPrefUser;
    private SharedPreferences sharedPrefLink;


    private RequestQueue requestQueue;
    private List<Favorito> listaFavoritos;
    private static final String BASE_URL = "http://172.22.21.207/backend/modules/api/favoritos/getfavoritos"; // URL corrigida


    public static synchronized SingletonGestorApp getInstance(Context context) {
        if (instance == null) {
            instance = new SingletonGestorApp(context);
            volleyQueue = Volley.newRequestQueue(context);
        }
        return instance;
    }

    private SingletonGestorApp(Context context) {
        artigos = new ArrayList<>();
        carrinhos = new ArrayList<>();
        categorias = new ArrayList<>();
        faturas = new ArrayList<>();
        ivas = new ArrayList<>();
        linhaCarrinhos = new ArrayList<>();
        artigoBD = new ArtigosDBHelper(context);
    }

    //region SETTERS DOS LISTENERS
    public void setArtigoListener(ArtigoListener artigoListener) {
        this.artigoListener = artigoListener;
    }

    public void setArtigosListener(ArtigosListener artigosListener) {
        this.artigosListener = artigosListener;
    }

    public void setCategoriaListener(CategoriaListener categoriaListener) {
        this.categoriaListener = categoriaListener;
    }

    public void setCategoriasListener(CategoriasListener categoriasListener) {
        this.categoriasListener = categoriasListener;
    }

    public void setCarrinhoAtivoListener(CarrinhoAtivoListener carrinhoAtivoListener) {
        this.carrinhoAtivoListener = carrinhoAtivoListener;
    }

    public void setCarrinhoListener(CarrinhoListener carrinhoListener) {
        this.carrinhoListener = carrinhoListener;
    }

    public void setCarrinhosListener(CarrinhosListener carrinhosListener) {
        this.carrinhosListener = carrinhosListener;
    }

    public void setFaturaListener(FaturaListener faturaListener) {
        this.faturaListener = faturaListener;
    }

    public void setFaturasListener(FaturasListener faturasListener) {
        this.faturasListener = faturasListener;
    }

    public void setIvaListener(IvaListener ivaListener) {
        this.ivaListener = ivaListener;
    }

    public void setIvasListener(IvasListener ivasListener) {
        this.ivasListener = ivasListener;
    }

    public void setLinhaCarrinhoListener(LinhaCarrinhoListener linhaCarrinhoListener) {
        this.linhaCarrinhoListener = linhaCarrinhoListener;
    }

    public void setLinhasCarrinhoListener(LinhasCarrinhoListener linhasCarrinhoListener) {
        this.linhasCarrinhoListener = linhasCarrinhoListener;
    }

    public void setLoginListener(LoginListener loginListener) {
        this.loginListener = loginListener;
    }
//endregion

    //region getId(modelos)
    public Artigo getArtigo(int id) {
        for (Artigo artigo : artigos) {
            if (artigo.getId() == id)
                return artigo;
        }
        return null;
    }

    public Carrinho getCarrinho(int id) {
        Iterator<Carrinho> iterator = carrinhos.iterator();
        while (iterator.hasNext()) {
            Carrinho carrinho = iterator.next();
            if (carrinho.getId() == id) {
                return carrinho;
            }
        }
        return null;
    }

    public Categoria getCategoria(int id) {
        for (Categoria categoria : categorias) {
            if (categoria.getId() == id)
                return categoria;
        }
        return null;
    }

    public Fatura getFatura(int id) {
        for (Fatura fatura : faturas) {
            if (fatura.getId() == id)
                return fatura;
        }
        return null;
    }

    public Iva getIva(int id) {
        for (Iva iva : ivas) {
            if (iva.getId() == id)
                return iva;
        }
        return null;
    }

    public LinhaCarrinho getLinhaCarrinho(int id) {
        for (LinhaCarrinho linhaCarrinho : linhaCarrinhos) {
            if (linhaCarrinho.getId() == id)
                return linhaCarrinho;
        }
        return null;
    }
//endregion

    public static boolean isConnectionInternet(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    public void setUrlAPI(String link, final Context context) {
        sharedPrefLink = context.getSharedPreferences("DADOS_LINK", Context.MODE_PRIVATE);
        if (sharedPrefLink != null) {
            SharedPreferences.Editor editor = sharedPrefLink.edit();
            editor.putString("LINK", link);
            editor.apply();
        }
    }

    public void getToken(final Context context) {
        sharedPrefUser = context.getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        if (sharedPrefUser != null) {
            TOKEN = sharedPrefUser.getString("TOKEN", "token");
        }
    }

    public void getUrlAPI(final Context context) {
        sharedPrefLink = context.getSharedPreferences("DADOS_LINK", Context.MODE_PRIVATE);
        if (sharedPrefLink != null) {
            UrlAPI = sharedPrefLink.getString("LINK", "link");
        }
    }

    public void loginAPI(String username, String password, final Context context) {

        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPI + "/user/login", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        boolean success = jsonResponse.getBoolean("success");
                        int userId = jsonResponse.getInt("userId");
                        String token = jsonResponse.getString("token");
                        String email = jsonResponse.getString("email");
                        String message = jsonResponse.getString("message");
                        String role = jsonResponse.getString("role");


                        SharedPreferences sharedPref = context.getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.putString("TOKEN", token);
                        editor.putString("EMAIL", email);
                        editor.putString("ROLE", role);
                        editor.putInt("ID_USER", userId);
                        editor.apply();

                        if (success) {
                            // Login bem-sucedido, faça o que for necessário
                            Toast.makeText(context, "Login bem-sucedido", Toast.LENGTH_SHORT).show();


                        } else {
                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(context, "Erro ao fazer login", Toast.LENGTH_SHORT).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    // Parâmetros que serão enviados no corpo da requisição
                    Map<String, String> params = new HashMap<>();
                    params.put("username", username);
                    params.put("password", password);
                    return params;
                }
            };

            // Adiciona a requisição na fila de Volley
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            requestQueue.add(req);
        }
    }


    //endregion
//region ACESSOS BD ARTIGOS
    public ArrayList<Artigo> getArtigosBD() {
        artigos = artigoBD.getAllArtigosBD();
        return new ArrayList<>(artigos);
    }

    public void adicionarArtigoBD(Artigo artigo) {
        artigoBD.adicionarArtigoBD(artigo);
    }

    public void adicionarAllArtigosBD(ArrayList<Artigo> artigos) {
        artigoBD.removerAllArtigosBD();

        for (Artigo artigo : artigos) {
            adicionarArtigoBD(artigo);
        }
    }

    public void editarArtigoBD(Artigo artigo) {
        if (artigo != null)
            artigoBD.editarArtigoBD(artigo);
    }

    public void removerArtigoBD(int idartigo) {
        artigoBD.removerArtigoBD(idartigo);
    }

    //endregion
//region PEDIDOS API ARTIGOS
    public void adicionarArtigoAPI(final Artigo artigo, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPI + "/artigos/adicionarartigo?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("API Response", response);


                    // guardar na bdlocal para funcionar offline
                    adicionarArtigoBD(ArtigoJsonParser.parserJsonArtigo(response));
                    // informar a vista
                    if (artigoListener != null)
                        artigoListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = ArtigoJsonParser.artigoParaJson(artigo);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    public void getAllArtigosAPI(final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
            // se nao tem internet vai buscar os livros a base de dados
            artigos = artigoBD.getAllArtigosBD();

            if (artigosListener != null)
                artigosListener.onRefreshListaArtigos(artigos);
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/artigos?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    artigos = ArtigoJsonParser.parserJsonArtigos(response);
                    adicionarAllArtigosBD(artigos);

                    // para informar a vista
                    if (artigosListener != null)
                        artigosListener.onRefreshListaArtigos(artigos);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    artigos = artigoBD.getAllArtigosBD();
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }


            });
            volleyQueue.add(req);
        }
    }

    public void removerArtigoAPI(final Artigo artigo, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.DELETE, UrlAPI + "/artigo/eliminarartigo/" + artigo.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // atualizar a BDLocal
                    removerArtigoBD(artigo.getId());
                    // informar a vista
                    if (artigoListener != null)
                        artigoListener.onRefreshDetalhes(MainActivity.DELETE);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    artigos = artigoBD.getAllArtigosBD();
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public void editarArtigoAPI(final Artigo artigo, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.PUT, UrlAPI + "/artigos/editarartigo/" + artigo.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // guardar na bdlocal para funcionar offline
                    editarArtigoBD(ArtigoJsonParser.parserJsonArtigo(response));
                    // informar a vista
                    if (artigoListener != null)
                        artigoListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = ArtigoJsonParser.artigoParaJson(artigo);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }
//endregion
//region PEDIDOS API CARRINHOS


    private void notifyCarrinhoAtivoListener(boolean success, int carrinhoId) {
        if (carrinhoAtivoListener != null) {
            carrinhoAtivoListener.onCarrinhoAtivoVerificado(success, carrinhoId);
        }
    }

    public void getCarrinhosAtivosAPI(int userId, final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);

            JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/carrinho/" + userId + "?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    carrinhos = CarrinhoJsonParser.parserJsonCarrinhos(response);
                    if (carrinhosListener != null) {
                        carrinhosListener.onRefreshListaCarrinhos(carrinhos);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro na chamada da API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public Carrinho getCarrinhoById(int carrinhoId, Context context) {
        final Carrinho[] carrinho = new Carrinho[1]; // Usando array para fazer um retorno assíncrono
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, UrlAPI + "/carrinho/" + carrinhoId + "?access-token=" + TOKEN, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // Pega os dados do carrinho da resposta
                            int id = response.getInt("id");
                            String data = response.getString("data");
                            double valorTotal = response.getDouble("valorTotal");
                            String estado = response.getString("estado");
                            double valorIva = response.getDouble("valorIva");
                            int userId = response.getInt("user_id");

                            // Cria o objeto Carrinho
                            carrinho[0] = new Carrinho(id, data, valorTotal, estado, valorIva, userId);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, "Erro ao carregar o carrinho", Toast.LENGTH_SHORT).show();
                    }
                });

        volleyQueue.add(request);
        return carrinho[0]; // Retorna o carrinho carregado
    }


    public ArrayList<Carrinho> getCarrinhosFinalizadosoAPI(int userId, final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/carrinho/finalizado/" + userId + "?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    carrinhos = CarrinhoJsonParser.parserJsonCarrinhos(response);

                    if (carrinhosListener != null) {
                        carrinhosListener.onRefreshListaCarrinhos(carrinhos);
                    }
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro na chamada da API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
        return carrinhos;
    }

    public void adicionarCarrinhoAPI(int userId, final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.POST, UrlAPI + "/carrinho/adicionarcarrinho/" + userId + "?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    if (carrinhoListener != null) {
                        carrinhoListener.onRefreshDetalhes(MainActivity.ADD);
                    }
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro na chamada da API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public void removerCarrinhoAPI(Carrinho carrinho, final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.DELETE, UrlAPI + "/carrinho/eliminarcarrinho/" + carrinho.getId() + "?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    carrinhos = CarrinhoJsonParser.parserJsonCarrinhos(response);

                    if (carrinhosListener != null) {
                        carrinhosListener.onRefreshListaCarrinhos(carrinhos);
                    }
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro na chamada da API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public void finalizarCarrinhoAPI(int idCarrinho, final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.PUT, UrlAPI + "/carrinho/finalizar/" + idCarrinho + "?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    carrinhos = CarrinhoJsonParser.parserJsonCarrinhos(response);

                    if (carrinhosListener != null) {
                        carrinhosListener.onRefreshListaCarrinhos(carrinhos);
                    }
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro na chamada da API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    //endregion
//region PEDIDOS API CATEGORIAS
    public void adicionarCategoriaAPI(final Categoria categoria, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPI + "/categorias/postcategoria?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (categoriaListener != null)
                        categoriaListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = CategoriaJsonParser.categoriaParaJson(categoria);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    public ArrayList<Categoria> getAllCategoriasAPI(final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();

        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/categorias?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    categorias = CategoriaJsonParser.parserJsonCategorias(response);

                    // para informar a vista
                    if (categoriasListener != null)
                        categoriasListener.onRefreshListaCategorias(categorias);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }

            });
            volleyQueue.add(req);
        }
        return categorias;
    }

    public void removerCategoriaAPI(final Categoria categoria, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.DELETE, UrlAPI + "/categorias/" + categoria.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // informar a vista
                    if (categoriaListener != null)
                        categoriaListener.onRefreshDetalhes(MainActivity.DELETE);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public void editarCategoriaAPI(final Categoria categoria, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.PUT, UrlAPI + "/categorias/" + categoria.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (categoriaListener != null)
                        categoriaListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = CategoriaJsonParser.categoriaParaJson(categoria);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    //endregion
//region PEDIDOS API FATURAS
    public void adicionarFaturaAPI(int idCarrinho, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPI + "/fatura/adicionarfatura/" + idCarrinho + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (faturaListener != null)
                        faturaListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public ArrayList<Fatura> getAllFaturasAPI(final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/fatura?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    faturas = FaturaJsonParser.parserJsonFaturas(response);

                    // para informar a vista
                    if (faturasListener != null)
                        faturasListener.onRefreshListaFaturas(faturas);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }

            });
            volleyQueue.add(req);
        }
        return faturas;
    }

    public void getFaturasClienteAPI(int userId, Context context, FaturasListener listener) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
            return;
        }

        // URL da API do backend
        getUrlAPI(context);
        getToken(context);
        JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/fatura/1/user?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                ArrayList<Fatura> faturas = new ArrayList<>();

                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject faturaJson = response.getJSONObject(i);

                        // Extrai os dados da fatura
                        int faturaId = faturaJson.getInt("fatura_id");
                        String data = faturaJson.getString("data");
                        int metodopagamento_id = faturaJson.getInt("metodopagamento_id"); // Não existe no json
                        int carrinho_id = faturaJson.getInt("carrinho_id");

                        // Extrai os dados do carrinho, se presente
                        JSONObject carrinhoJson = faturaJson.optJSONObject("carrinho");
                        Carrinho carrinho = null;
                        if (carrinhoJson != null) {
                            int carrinhoId = carrinhoJson.getInt("id");
                            String dataCarrinho = carrinhoJson.getString("data");
                            double valorIva = carrinhoJson.getDouble("valor_iva");
                            double valorTotal = carrinhoJson.getDouble("valor_total");
                            String estado = carrinhoJson.getString("estado");
                            int user_id = carrinhoJson.getInt("user_id");

                            carrinho = new Carrinho(carrinhoId, dataCarrinho, valorTotal, estado, valorIva, user_id);
                        }

                        // Cria uma instância de Fatura
                        Fatura fatura = new Fatura(faturaId, data, userId, carrinho, metodopagamento_id, carrinho_id); //metodopagamento_id não existe no json
                        faturas.add(fatura);
                    }

                    // Passa as faturas para o listener
                    listener.onRefreshListaFaturas(faturas);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(context, "Erro ao processar faturas", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Erro na requisição", Toast.LENGTH_SHORT).show();
            }
        });

        // Adiciona a requisição na fila do Volley
        volleyQueue.add(req);
    }

    public void anularFaturaAPI(final Fatura fatura, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.PUT, UrlAPI + "/fatura/anularfatura/" + fatura.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (faturaListener != null)
                        faturaListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    //endregion
//region PEDIDOS API IVAS
    public void adicionarIvaAPI(final Iva iva, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPI + "/iva/adicionariva?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (ivaListener != null)
                        ivaListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = IvaJsonParser.ivaParaJson(iva);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    public ArrayList<Iva> getAllIvasAPI(final Context context) {
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        } else {
            getUrlAPI(context);
            getToken(context);
            JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/iva?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    ivas = IvaJsonParser.parserJsonIvas(response);

                    // para informar a vista
                    if (ivasListener != null)
                        ivasListener.onRefreshListaIvas(ivas);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }

            });
            volleyQueue.add(req);
        }
        return ivas;
    }

    public void removerIvaAPI(final Iva iva, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.DELETE, UrlAPI + "/iva/eliminariva/" + iva.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // informar a vista
                    if (ivaListener != null)
                        ivaListener.onRefreshDetalhes(MainActivity.DELETE);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public void editarIvaAPI(final Iva iva, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.PUT, UrlAPI + "/iva/editariva/" + iva.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (ivaListener != null)
                        ivaListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = IvaJsonParser.ivaParaJson(iva);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    //endregion
//region PEDIDOS API LINHAS CARRINHOS
    public void getLinhasCarrinhoAPI(int faturaId, Context context, LinhasCarrinhoListener listener) {/*
        if (!isConnectionInternet(context)) {
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
            return;
        }

        getUrlAPI(context);
        getToken(context);
        JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, UrlAPI + "/fatura/" + faturaId + "/linhas?access-token=" + TOKEN, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response == null || response.length() == 0) {
                    Toast.makeText(context, "Nenhuma linha de carrinho disponível", Toast.LENGTH_SHORT).show();
                    return;
                }

                ArrayList<LinhaCarrinho> linhasCarrinho = new ArrayList<>();

                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject linhaJson = response.getJSONObject(i);

                        int linhaId = linhaJson.getInt("id");
                        int quantidade = linhaJson.getInt("quantidade");
                        double valor = linhaJson.getDouble("valor");
                        int artigoId = linhaJson.getInt("artigo_id");
                        String nomeArtigo = linhaJson.optString("nome_artigo", "Artigo não disponível");

                        LinhaCarrinho linhaCarrinho = new LinhaCarrinho(linhaId, quantidade, valor, artigoId, nomeArtigo);
                        linhasCarrinho.add(linhaCarrinho);
                    }

                    listener.onLinhasCarrinhoReceived(linhasCarrinho);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(context, "Erro ao processar as linhas do carrinho", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Erro na requisição das linhas", Toast.LENGTH_SHORT).show();
            }
        });

        volleyQueue.add(req);*/
    }

    public void adicionarLinhaCarrinhoAPI(int idArtigo, int idCarrinho, int quantidade, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPI + "/linha/adicionarlinha?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (linhaCarrinhoListener != null)
                        linhaCarrinhoListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    JSONObject jsonBody = new JSONObject();
                    try {
                        jsonBody.put("quantidade", quantidade);
                        jsonBody.put("artigo_id", idArtigo);
                        jsonBody.put("carrinho_id", idCarrinho);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return jsonBody.toString().getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    public void removerLinhaCarrinhoAPI(final LinhaCarrinho linhaCarrinho, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.DELETE, UrlAPI + "/linha/eliminarlinha/" + linhaCarrinho.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // informar a vista
                    if (linhaCarrinhoListener != null)
                        linhaCarrinhoListener.onRefreshDetalhes(MainActivity.DELETE);
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            });
            volleyQueue.add(req);
        }
    }

    public void editarLinhaCarrinhoAPI(final LinhaCarrinho linhaCarrinho, final Context context) {
        if (!isConnectionInternet(context))
            Toast.makeText(context, "Não tem ligação à Internet", Toast.LENGTH_SHORT).show();
        else {
            getUrlAPI(context);
            getToken(context);
            StringRequest req = new StringRequest(Request.Method.PUT, UrlAPI + "/linha/linha/" + linhaCarrinho.getId() + "?access-token=" + TOKEN, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (linhaCarrinhoListener != null)
                        linhaCarrinhoListener.onRefreshDetalhes(MainActivity.ADD);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro ao aceder a API", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public byte[] getBody() {
                    String json = LinhaCarrinhoJsonParser.linhaCarrinhoParaJson(linhaCarrinho);
                    return json.getBytes();
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            volleyQueue.add(req);
        }
    }

    //endregion
    //FAVORITOS
    public void carregarFavoritos(int userId, final FavoritosListener listener) {
        String url = BASE_URL + "?user_id=" + userId;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET, url, null,
                response -> {
                    listaFavoritos.clear();
                    try {
                        boolean success = response.getBoolean("success");
                        if (success) {
                            JSONArray data = response.getJSONArray("data");
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject obj = data.getJSONObject(i);
                                Favorito favorito = new Favorito(
                                        obj.getInt("id"),
                                        obj.getString("nome"),
                                        obj.getString("descricao"),
                                        obj.getString("imagem")
                                );
                                listaFavoritos.add(favorito);
                            }
                            listener.onFavoritosLoaded(listaFavoritos);
                        } else {
                            Log.e("API Error", "Erro: Nenhum favorito encontrado.");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Log.e("Erro API", "Erro ao carregar favoritos: " + error.getMessage())
        );

        requestQueue.add(jsonObjectRequest);
    }

    public void adicionarFavoritoAPI(int userId, int artigoId, Context context) {
        SharedPreferences sp = context.getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        userId = sp.getInt("ID_USER", 0);
        if (userId == 0) {
            Toast.makeText(context, "Você precisa estar logado para adicionar aos favoritos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Construa o objeto JSON com os dados necessários
        JSONObject requestBody = new JSONObject();
        try {
            requestBody.put("user_id", userId);
            requestBody.put("artigo_id", artigoId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String url = "http://localhost/lojadeinformatica/backend/modules/api/favoritos/postfavorito"; // ajuste a URL conforme necessário

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, requestBody,
                response -> {
                    // Tratar a resposta da API se necessário
                },
                error -> {
                    // Tratar o erro
                });

        getRequestQueue(context).add(jsonObjectRequest);
    }

    private RequestQueue getRequestQueue(Context context) {
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(context.getApplicationContext());
        }
        return requestQueue;
    }
}

//endregion

