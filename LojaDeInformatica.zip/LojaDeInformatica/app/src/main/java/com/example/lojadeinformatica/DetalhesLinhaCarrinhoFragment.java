package com.example.lojadeinformatica;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.lojadeinformatica.modelo.LinhaCarrinho;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;

import java.util.ArrayList;

public class DetalhesLinhaCarrinhoFragment extends Fragment {

    private TextView tvIdArtigo, tvQuantidade, tvPreco;

    public DetalhesLinhaCarrinhoFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_lista_linha_carrinho, container, false);

        tvQuantidade = view.findViewById(R.id.tvQuantidade);

    //    carregarLinhaCarrinho();
        return view;
    }

 /*   private void carregarLinhaCarrinho() {
        ArrayList<LinhaCarrinho> linhaCarrinhos;
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("CARRINHO_PREFS", Context.MODE_PRIVATE);
        int CARRINHO_ID = sharedPreferences.getInt("CARRINHO_ID", 0);
       // linhaCarrinhos = SingletonGestorApp.getInstance(getContext()).getLinhasCarrinhoFatura(CARRINHO_ID,getContext());

        if (linhaCarrinhos!=null) {
            LinhaCarrinho linhaCarrinho = linhaCarrinhos.get(0);
            tvIdArtigo.setText(linhaCarrinho.getArtigo_id());
            tvQuantidade.setText(String.valueOf(linhaCarrinho.getQuantidade()));
            tvPreco.setText(String.valueOf(linhaCarrinho.getValor()));
        }
    }*/
}
