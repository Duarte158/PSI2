package com.example.lojadeinformatica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lojadeinformatica.listeners.LinhaCarrinhoListener;
import com.example.lojadeinformatica.modelo.LinhaCarrinho;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DetalhesLinhaCarrinhoActivity extends AppCompatActivity implements LinhaCarrinhoListener {

    public static final String ID_LINHA = "id";
    private final int MIN_CHAR = 3;
    private EditText etValor, etReferencia, etIdCarrinho, etIdArtigo, etQuantidade;
    private FloatingActionButton fabGuardar;
    private LinhaCarrinho linhaCarrinho;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_linha_carrinho);
        etQuantidade = findViewById(R.id.etQuantidade);
        etValor = findViewById(R.id.etValor);

        fabGuardar = findViewById(R.id.fabGuardar);
        SingletonGestorApp.getInstance(getApplicationContext()).setLinhaCarrinhoListener(this);

        int id = getIntent().getIntExtra(ID_LINHA, 0);
        if (id != 0) {
            linhaCarrinho = SingletonGestorApp.getInstance(getApplicationContext()).getLinhaCarrinho(id);
            if (linhaCarrinho != null) {
                carregarLinha();
                fabGuardar.setImageResource(R.drawable.ic_guardar);
            } else {
                finish();
            }
        } else {
            setTitle("Adicionar Linha");
            fabGuardar.setImageResource(R.drawable.ic_adicionar);
        }

        fabGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (linhaCarrinho != null) { // Linha já existe
                    if (isLinhaValido()) {
                        linhaCarrinho.setQuantidade(Integer.parseInt(etQuantidade.getText().toString()));
                        linhaCarrinho.setValor(Double.parseDouble(etValor.getText().toString()));

                        SingletonGestorApp.getInstance(getApplicationContext()).editarLinhaCarrinhoAPI(linhaCarrinho, getApplicationContext());
                    }
                } else { // Linha para criar
                    if (isLinhaValido()) {
                        linhaCarrinho = new LinhaCarrinho(0,
                                Integer.parseInt(etQuantidade.getText().toString()),
                                Double.parseDouble(etValor.getText().toString()),
                                Integer.parseInt(etIdArtigo.getText().toString()),
                                Integer.parseInt(etIdCarrinho.getText().toString()),
                                "");
                    }
                }
            }
        });

    }

    private boolean isLinhaValido() {
        String id = etIdArtigo.getText().toString();
        String quantiadade = etQuantidade.getText().toString();
        String valor = etValor.getText().toString();

        if (id.isEmpty()) {
            etIdArtigo.setError("Id Artigo inválida");
            return false;
        }

        if (quantiadade.length() < MIN_CHAR) {
            etQuantidade.setError("Quantidade inválida");
            return false;
        }
        if (valor.isEmpty()) {
            etValor.setError("Valor inválido");
            return false;
        }

        return true;
    }

    private void carregarLinha() {
        setTitle("Detalhes: " + linhaCarrinho.getId());

        etQuantidade.setText(String.valueOf(linhaCarrinho.getQuantidade()));
        etValor.setText(String.valueOf(linhaCarrinho.getValor()));
        etIdArtigo.setText(String.valueOf(linhaCarrinho.getNomeArtigo()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        String role = sharedPreferences.getString("ROLE", "");

        if (linhaCarrinho != null) {
            getMenuInflater().inflate(R.menu.menu_remover, menu);
            return true;

        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itemRemover) {
            dialogRemover();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogRemover() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remover Linha")
                .setMessage("Tem a certeza que pertende remover a linha?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SingletonGestorApp.getInstance(getApplicationContext()).removerLinhaCarrinhoAPI(linhaCarrinho, getApplicationContext());
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }

    @Override
    public void onRefreshDetalhes(int op) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}