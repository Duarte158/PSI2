package com.example.lojadeinformatica.listeners;

public interface IvaListener {
    void onRefreshDetalhes(int op);
}
