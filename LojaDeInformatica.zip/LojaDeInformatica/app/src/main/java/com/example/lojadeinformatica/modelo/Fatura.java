package com.example.lojadeinformatica.modelo;

import java.io.Serializable;
import java.util.ArrayList;

public class Fatura implements Serializable {
    private int id;
    private String data;
    private int userId;
    private Carrinho carrinho;
    private int metodoPagamentoId;
    private int carrinhoId;
    private ArrayList<LinhaCarrinho> linhasCarrinho;

    public Fatura(int id, String data, int userId, Carrinho carrinho, int metodoPagamentoId, int carrinhoId) {
        this.id = id;
        this.data = data;
        this.userId = userId;
        this.carrinho = carrinho;
        this.metodoPagamentoId = metodoPagamentoId;
        this.carrinhoId = carrinhoId;
        this.linhasCarrinho = linhasCarrinho;
    }


    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getUser_id() {
        return userId;
    }

    public void setUser_id(int user_id) {
        this.userId = user_id;
    }

    public int getMetodoPagamento_id() {
        return metodoPagamentoId;
    }

    public void setMetodoPagamento_id(int metodoPagamento_id) {
        this.metodoPagamentoId = metodoPagamento_id;
    }

    public int getCarrinho_id() {
        return carrinhoId;
    }

    public void setCarrinho_id(int carrinho_id) {
        this.carrinho = carrinho;
    }

    public Carrinho getCarrinho() {
        return carrinho;
    }

    public void setCarrinho(Carrinho carrinho) {
        this.carrinho = carrinho;
    }

    public ArrayList<LinhaCarrinho> getLinhasCarrinho() {
        return linhasCarrinho;
    }

    public void setLinhasCarrinho(ArrayList<LinhaCarrinho> linhasCarrinho) {
        this.linhasCarrinho = linhasCarrinho;
    }
}
