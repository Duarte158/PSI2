package com.example.lojadeinformatica;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.lojadeinformatica.listeners.CarrinhoListener;
import com.example.lojadeinformatica.modelo.Carrinho;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class CriarCarrinhoActivity extends AppCompatActivity implements CarrinhoListener {

    private Carrinho carrinho;
    private String token;
    private int user_id;
    private FloatingActionButton fabGuardar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SingletonGestorApp.getInstance(getApplicationContext()).getAllArtigosAPI(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_carrinho);

        if(carrinho!=null){
            carregarCarrinho();
        }
        SingletonGestorApp.getInstance(getApplicationContext()).setCarrinhoListener(this);
    }

    private void carregarCarrinho() {
        Resources res=getResources();
        setTitle("Carrinho");
    }

    @Override
    public void onRefreshDetalhes(int operacao) {
        Intent intent = new Intent();
        intent.putExtra(MainActivity.OP, operacao);
        setResult(RESULT_OK, intent);
        finish();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(carrinho!=null){
            getMenuInflater().inflate(R.menu.menu_remover,menu);
            return super.onCreateOptionsMenu(menu);
        }
        return false;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itemRemover) {
            dialogRemover();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    //remover pedido
    private void dialogRemover() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remover Carrinho")
                .setMessage("Tem a certeza que pretende remover o carrinho?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SingletonGestorApp.getInstance(getApplicationContext()).removerCarrinhoAPI(carrinho,getApplicationContext());
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Nao fazer nada
                    }
                })
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("USER_ID", 0);
        SingletonGestorApp.getInstance(getApplicationContext()).getCarrinhosAtivosAPI(userId,getApplicationContext());
        finish();
    }


    public void onClicklinhas(View view) {

        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("USER_ID", 0);
        SingletonGestorApp.getInstance(getApplicationContext()).adicionarCarrinhoAPI(userId,getApplicationContext());
        finish();
    }

}
