package com.example.lojadeinformatica.listeners;

public interface CountListener {

    void onRefreshCount(int count);
}
