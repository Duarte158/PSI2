package com.example.lojadeinformatica.utils;

import android.util.Log;

import com.example.lojadeinformatica.modelo.Carrinho;
import com.example.lojadeinformatica.modelo.Fatura;
import com.example.lojadeinformatica.modelo.LinhaCarrinho;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FaturaJsonParser {

    private static final String TAG = "FaturaJsonParser";

    public static ArrayList<Fatura> parserJsonFaturas(JSONArray response) {
        ArrayList<Fatura> faturas = new ArrayList<>();
        try {
            for (int i = 0; i < response.length(); i++) {
                JSONObject faturaJson = response.getJSONObject(i);

                // Log para ver o JSON completo da fatura
                Log.d(TAG, "Fatura JSON: " + faturaJson.toString());

                // Extrair os campos da fatura. Agora usamos "id" em vez de "fatura_id"
                int id = faturaJson.getInt("id"); // Substituímos fatura_id por id
                String data = faturaJson.optString("data", "Data não disponível");
                int user_id = faturaJson.optInt("user_id", -1);
                int metodoPagamento_id = faturaJson.optInt("metodoPagamento_id", -1);
                int carrinho_id = faturaJson.optInt("carrinho_id", -1);

                // Extrai os dados do carrinho, caso estejam disponíveis
                JSONObject carrinhoJson = faturaJson.optJSONObject("carrinho");
                Carrinho carrinho = null;

                if (carrinhoJson != null) {
                    int carrinhoId = carrinhoJson.optInt("id", -1);  // Usando valores padrão (caso não existam)
                    String carrinhoData = carrinhoJson.optString("data", "Data não disponível");
                    double valorTotal = carrinhoJson.optDouble("valor_total", 0.0);
                    String estado = carrinhoJson.optString("estado", "Estado desconhecido");
                    double valorIva = carrinhoJson.optDouble("valor_iva", 0.0);
                    int carrinhoUserId = carrinhoJson.optInt("user_id", -1);
                    int metodoPagamento = carrinhoJson.optInt("metodo_pagamento", -1);

                    // Cria uma instância de Carrinho
                    carrinho = new Carrinho(carrinhoId, carrinhoData, valorTotal, estado, valorIva, carrinhoUserId);
                } else {
                    // Caso não haja carrinho, exibe no log
                    Log.d(TAG, "Carrinho não encontrado para a fatura ID: " + id);
                }

                // Extrai os dados das linhas do carrinho, caso estejam disponíveis
                ArrayList<LinhaCarrinho> linhasCarrinho = new ArrayList<>();
                JSONArray linhasArray = faturaJson.optJSONArray("linhas_carrinho");
                if (linhasArray != null) {
                    for (int j = 0; j < linhasArray.length(); j++) {
                        JSONObject linhaJson = linhasArray.getJSONObject(j);

                        int linhaId = linhaJson.getInt("id");
                        int quantidade = linhaJson.getInt("quantidade");
                        double valor = linhaJson.getDouble("valor");
                        int artigoId = linhaJson.getInt("artigo_id");
                        int carrinnho_id = linhaJson.getInt("carrinho_id");
                        String nomeArtigo = linhaJson.optString("nome_artigo", "Artigo não disponível");

                        // Cria uma instância de LinhaCarrinho
                        LinhaCarrinho linhaCarrinho = new LinhaCarrinho(linhaId, quantidade, valor,carrinnho_id, artigoId, nomeArtigo);
                        linhasCarrinho.add(linhaCarrinho);
                    }
                } else {
                    // Caso não haja linhas de carrinho, exibe no log
                    Log.d(TAG, "Linhas do carrinho não encontradas para a fatura ID: " + id);
                }

                // Cria uma nova instância de Fatura com os campos extraídos
                Fatura fatura = new Fatura(id, data, user_id, carrinho, metodoPagamento_id, carrinho_id);
                faturas.add(fatura); // Adiciona a fatura à lista
            }
        } catch (JSONException e) {
            Log.e(TAG, "Erro ao parsear JSON", e); // Log para erros de parsing JSON
        }
        return faturas; // Retorna a lista de faturas
    }
}
