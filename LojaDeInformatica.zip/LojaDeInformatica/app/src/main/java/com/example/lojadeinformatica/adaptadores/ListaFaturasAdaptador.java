package com.example.lojadeinformatica.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.lojadeinformatica.R;
import com.example.lojadeinformatica.modelo.Fatura;

import java.util.ArrayList;
import java.util.List;

public class ListaFaturasAdaptador extends ArrayAdapter<Fatura> {
    private Context context;
    private List<Fatura> faturas;

    public ListaFaturasAdaptador(Context context, List<Fatura> faturas) {
        super(context, R.layout.item_lista_fatura, faturas);
        this.context = context;
        this.faturas = faturas;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolderLista viewHolder;

        if (convertView == null) {
            // Inflar o layout do item da lista
            convertView = LayoutInflater.from(context).inflate(R.layout.item_lista_fatura, parent, false);

            // Criar o ViewHolder
            viewHolder = new ViewHolderLista(convertView);

            // Definir o ViewHolder como uma tag do item
            convertView.setTag(viewHolder);
        } else {
            // Recuperar o ViewHolder já existente
            viewHolder = (ViewHolderLista) convertView.getTag();
        }

        // Obter a fatura da lista
        Fatura fatura = faturas.get(position);

        // Atualizar os dados da fatura
        viewHolder.update(fatura);

        return convertView;
    }

    // ViewHolder para melhorar a performance do ListView
    private class ViewHolderLista {
        private TextView tvData, tvValorTotal, tvEstadoCarrinho, tvFaturaId;

        public ViewHolderLista(View view) {
            tvData = view.findViewById(R.id.tvData);
            tvValorTotal = view.findViewById(R.id.tvValorTotal);
            tvEstadoCarrinho = view.findViewById(R.id.tvEstado);
            tvFaturaId = view.findViewById(R.id.tvFaturaId);
        }

        public void update(Fatura fatura) {
            // Atualiza os dados gerais da fatura
            tvData.setText(fatura.getData() != null ? fatura.getData() : "Data não disponível");

            if (fatura.getCarrinho() != null) {
                // Atualiza os dados do carrinho associado à fatura
                tvValorTotal.setText(String.valueOf(fatura.getCarrinho().getValorTotal()));
                tvEstadoCarrinho.setText(fatura.getCarrinho().getEstado());
                tvFaturaId.setText(String.valueOf(fatura.getId()));
            } else {
                // Preenche com valores padrão caso o carrinho seja null
                tvValorTotal.setText("N/A");
                tvEstadoCarrinho.setText("N/A");
                tvFaturaId.setText("N/A");
            }
        }
    }
}
