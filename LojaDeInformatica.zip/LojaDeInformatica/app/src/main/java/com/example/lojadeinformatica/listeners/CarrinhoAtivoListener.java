package com.example.lojadeinformatica.listeners;

public interface CarrinhoAtivoListener {
    void onCarrinhoAtivoVerificado(boolean carrinhoAtivo, int carrinhoId);
}
