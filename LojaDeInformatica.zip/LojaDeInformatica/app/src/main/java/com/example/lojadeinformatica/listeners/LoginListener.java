package com.example.lojadeinformatica.listeners;

public interface LoginListener {
    void onRefreshLogin(boolean success, String mensagem, String token, String email, String role, int user_id);
}
