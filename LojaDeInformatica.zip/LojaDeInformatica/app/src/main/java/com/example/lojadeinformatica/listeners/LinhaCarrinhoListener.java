package com.example.lojadeinformatica.listeners;

public interface LinhaCarrinhoListener {
    void onRefreshDetalhes(int op);
}