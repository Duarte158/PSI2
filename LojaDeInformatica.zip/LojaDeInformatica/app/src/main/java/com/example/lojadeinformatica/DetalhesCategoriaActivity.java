package com.example.lojadeinformatica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.example.lojadeinformatica.listeners.CategoriaListener;
import com.example.lojadeinformatica.modelo.Categoria;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DetalhesCategoriaActivity extends AppCompatActivity implements CategoriaListener {

    public static final String ID_CATEGORIA = "id";
    private final int MIN_CHAR = 3;
    private EditText etDescricao;
    private FloatingActionButton fabGuardar;
    private Categoria categoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_categoria);

        // Configurar a Toolbar como ActionBar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Exibir o ícone de "voltar" (opcional, se desejar ter um botão de voltar)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Detalhes Categoria"); // Título da Toolbar

        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        String role = sharedPreferences.getString("ROLE", "");

        etDescricao = findViewById(R.id.etDescricao);
        fabGuardar = findViewById(R.id.fabGuardar);
        SingletonGestorApp.getInstance(getApplicationContext()).setCategoriaListener(this);

        // Recuperar categoria do intent
        int id = getIntent().getIntExtra(ID_CATEGORIA, 0);
        if (id != 0) {
            categoria = SingletonGestorApp.getInstance(getApplicationContext()).getCategoria(id);
            if (categoria != null) {
                carregarCategoria();
                fabGuardar.setImageResource(R.drawable.ic_guardar);
            } else {
                // Algo de errado aconteceu
                finish();
            }
        } else {
            setTitle("Adicionar Categoria");
            fabGuardar.setImageResource(R.drawable.ic_adicionar);
        }

        // Comportamento para "cliente" role
        if ("cliente".equals(role)) {
            etDescricao.setKeyListener(null);
            fabGuardar.setVisibility(View.GONE);
        } else {
            fabGuardar.setVisibility(View.VISIBLE);
            fabGuardar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (categoria != null) { // Categoria já existe
                        if (isCategoriaValida()) {
                            categoria.setDescricao(etDescricao.getText().toString());
                            SingletonGestorApp.getInstance(getApplicationContext()).editarCategoriaAPI(categoria, getApplicationContext());
                        }
                    } else { // Categoria para criar
                        if (isCategoriaValida()) {
                            categoria = new Categoria(0, etDescricao.getText().toString());
                            SingletonGestorApp.getInstance(getApplicationContext()).adicionarCategoriaAPI(categoria, getApplicationContext());
                        }
                    }
                }
            });
        }
    }

    // Método para validar a descrição da categoria
    private boolean isCategoriaValida() {
        String descricao = etDescricao.getText().toString();
        if (descricao.length() < MIN_CHAR) {
            etDescricao.setError("Descrição inválida");
            return false;
        }
        return true;
    }

    // Método para carregar as informações da categoria na interface
    private void carregarCategoria() {
        setTitle("Detalhes: " + categoria.getDescricao());
        etDescricao.setText(categoria.getDescricao());
    }

    // Inflar o menu de opções
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SharedPreferences sharedPreferences = getSharedPreferences("DADOS_USER", Context.MODE_PRIVATE);
        String role = sharedPreferences.getString("ROLE", "");
        Log.d("DEBUG_ROLE", "Role: " + role);
        Log.d("DEBUG_CATEGORIA", "Categoria: " + (categoria != null ? categoria.toString() : "null"));

        // Adicionar menu "Remover" se não for cliente e se houver categoria
        if (!"cliente".equals(role)) {
            if (categoria != null) {
                getMenuInflater().inflate(R.menu.menu_remover, menu);
                Log.d("DEBUG_MENU", "Menu Remover Inflado");
                return true;
            }
        }
        return super.onCreateOptionsMenu(menu);
    }

    // Lidar com a seleção do item do menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itemRemover) {
            dialogRemover();
            return true;
        }
        // Para o botão "Voltar" na Toolbar
        else if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Diálogo para confirmar a remoção da categoria
    private void dialogRemover() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remover Categoria")
                .setMessage("Tem a certeza que pretende remover a categoria?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SingletonGestorApp.getInstance(getApplicationContext()).removerCategoriaAPI(categoria, getApplicationContext());
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }

    @Override
    public void onRefreshDetalhes(int op) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}
