package com.example.lojadeinformatica.utils;

import com.example.lojadeinformatica.modelo.LinhaCarrinho;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LinhaCarrinhoJsonParser {

    public static ArrayList<LinhaCarrinho> parserJsonLinhasCarrinho(JSONArray response) {
        ArrayList<LinhaCarrinho> linhasCarrinho = new ArrayList<>();
        try {
            for (int i = 0; i < response.length(); i++) {
                JSONObject linhaCarrinhoJson = response.getJSONObject(i);
                int id = linhaCarrinhoJson.getInt("id");
                int quantidade = linhaCarrinhoJson.getInt("quantidade");
                float valor = (float) linhaCarrinhoJson.getDouble("valor");
                int artigos_id = linhaCarrinhoJson.getInt("artigos_id");
                int carrinhocompras_id = linhaCarrinhoJson.getInt("carrinhocompras_id");
                String nomeArtigo = linhaCarrinhoJson.getString("nomeArtigo");


                LinhaCarrinho linhaCarrinho = new LinhaCarrinho(id, quantidade, valor, carrinhocompras_id, artigos_id, nomeArtigo);
                linhasCarrinho.add(linhaCarrinho);
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return linhasCarrinho;
    }

    public static LinhaCarrinho parserJsonLinhaCarrinho(String response) {
        try {
            JSONObject jsonLinhaCarrinho = new JSONObject(response);

            int id = jsonLinhaCarrinho.optInt("id", -1);
            int quantidade = jsonLinhaCarrinho.optInt("quantidade", 0);
            float valor = (float) jsonLinhaCarrinho.optDouble("valor", 0.0);
            String referencia = jsonLinhaCarrinho.optString("referencia", "");
            int artigos_id = jsonLinhaCarrinho.optInt("artigos_id", -1);
            int carrinhocompras_id = jsonLinhaCarrinho.optInt("carrinhocompras_id", -1);
            String nomeArtigo = jsonLinhaCarrinho.optString("nomeArtigo", "");

            LinhaCarrinho linhaCarrinho = new LinhaCarrinho(id, quantidade, valor, carrinhocompras_id, artigos_id, nomeArtigo);
            return linhaCarrinho;

        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String linhaCarrinhoParaJson(LinhaCarrinho linhaCarrinho) {
        JSONObject jsonLinhaCarrinho = new JSONObject();
        try {
            jsonLinhaCarrinho.put("quantidade", linhaCarrinho.getQuantidade());
            jsonLinhaCarrinho.put("artigos_id", linhaCarrinho.getArtigo_id());
            jsonLinhaCarrinho.put("carrinhocompras_id", linhaCarrinho.getCarrinho_id());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonLinhaCarrinho.toString();
    }
}
