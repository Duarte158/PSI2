    package com.example.lojadeinformatica.adaptadores;

    import android.content.Context;
    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.ArrayAdapter;
    import android.widget.BaseAdapter;
    import android.widget.TextView;

    import androidx.annotation.NonNull;
    import androidx.annotation.Nullable;

    import com.example.lojadeinformatica.modelo.LinhaCarrinho;
    import com.example.lojadeinformatica.R;

    import java.util.ArrayList;
    import java.util.Locale;

    public class LinhasCarrinhoAdapter extends ArrayAdapter<LinhaCarrinho> {
        private Context context;
        private ArrayList<LinhaCarrinho> linhasCarrinho;

        public LinhasCarrinhoAdapter(Context context, ArrayList<LinhaCarrinho> linhasCarrinho) {
            super(context, 0, linhasCarrinho);
            this.context = context;
            this.linhasCarrinho = linhasCarrinho;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.item_lista_linha_carrinho, parent, false);
            }

            LinhaCarrinho linhaCarrinho = linhasCarrinho.get(position);

            TextView tvNomeArtigo = convertView.findViewById(R.id.tvNomeArtigo);
            TextView tvQuantidade = convertView.findViewById(R.id.tvQuantidade);
            TextView tvValor = convertView.findViewById(R.id.tvValor);

            tvNomeArtigo.setText(linhaCarrinho.getNomeArtigo());
            tvQuantidade.setText(String.valueOf(linhaCarrinho.getQuantidade()));
            tvValor.setText(String.format(Locale.getDefault(), "%.2f", linhaCarrinho.getValor()));

            return convertView;
        }
    }
