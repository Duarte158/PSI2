package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Artigo;

import java.util.ArrayList;

public interface ArtigosListener {
    void onRefreshListaArtigos(ArrayList<Artigo> listaArtigos);
}
