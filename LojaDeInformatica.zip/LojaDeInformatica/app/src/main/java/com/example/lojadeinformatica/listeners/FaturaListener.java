package com.example.lojadeinformatica.listeners;

public interface FaturaListener {
    void onRefreshDetalhes(int op);
}

