package com.example.lojadeinformatica.listeners;

public interface ArtigoListener {
    void onRefreshDetalhes(int op);
}
