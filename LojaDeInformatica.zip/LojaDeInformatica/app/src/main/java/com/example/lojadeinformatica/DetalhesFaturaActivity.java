package com.example.lojadeinformatica;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.Menu;
import android.widget.TextView;

import com.example.lojadeinformatica.listeners.FaturaListener;
import com.example.lojadeinformatica.modelo.Fatura;
import com.example.lojadeinformatica.modelo.SingletonGestorApp;

public class DetalhesFaturaActivity extends AppCompatActivity implements FaturaListener {

    public static final String ID_FATURA = "id";
    private TextView tvdata, tvValotTotal, tvEstado, tvValor, tvValorIva, tvIdUser;
    private Fatura fatura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_fatura);

        tvdata = findViewById(R.id.tvData);
        tvValotTotal = findViewById(R.id.tvValorTotal);
        tvValorIva = findViewById(R.id.tvValorIva);
        SingletonGestorApp.getInstance(getApplicationContext()).setFaturaListener(this);

        int id = getIntent().getIntExtra(ID_FATURA, 0);
        if (id != 0) {
            fatura = SingletonGestorApp.getInstance(getApplicationContext()).getFatura(id);
            if (fatura != null) {
                carregarFatura();
            } else {
                finish();
            }
        }
    }
    private void carregarFatura() {
        setTitle("Detalhes da Fatura: " + fatura.getId());

      /*  if (fatura.getData() != null) {
            tvdata.setText(fatura.getData());
        }

        if (fatura.getValorTotal() != 0.0) {
            tvValotTotal.setText(String.valueOf(fatura.getValorTotal()));
        }

        if (fatura.getEstado() != null) {
            tvEstado.setText(fatura.getEstado());
        }

        if (fatura.getValor() != 0.0) {
            tvValor.setText(String.valueOf(fatura.getValor()));
        }

        if (fatura.getValorIva() != 0.0) {
            tvValorIva.setText(String.valueOf(fatura.getValorIva()));
        }

        if (fatura.getUsers_id() != 0) {
            tvIdUser.setText(String.valueOf(fatura.getUsers_id()));
        }*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (fatura != null) {
            getMenuInflater().inflate(R.menu.menu_anular, menu);
            return true;
        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itemRemover) {
            dialogRemover();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogRemover() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Anular Fatura")
                .setMessage("Tem a certeza que pretende anular a fatura?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SingletonGestorApp.getInstance(getApplicationContext()).anularFaturaAPI(fatura, getApplicationContext());
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }

    @Override
    public void onRefreshDetalhes(int op) {
        Intent intent= new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}