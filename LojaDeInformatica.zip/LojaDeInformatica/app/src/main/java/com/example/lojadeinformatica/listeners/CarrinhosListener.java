package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Carrinho;

import java.util.ArrayList;

public interface CarrinhosListener {
    void onRefreshListaCarrinhos(ArrayList<Carrinho> carrinhos);
}
