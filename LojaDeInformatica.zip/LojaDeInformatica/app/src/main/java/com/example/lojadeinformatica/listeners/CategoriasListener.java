package com.example.lojadeinformatica.listeners;

import com.example.lojadeinformatica.modelo.Categoria;

import java.util.ArrayList;

public interface CategoriasListener {
    void onRefreshListaCategorias(ArrayList<Categoria> listaCategorias);
}
