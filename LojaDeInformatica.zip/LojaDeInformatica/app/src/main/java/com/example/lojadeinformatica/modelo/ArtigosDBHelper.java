package com.example.lojadeinformatica.modelo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ArtigosDBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "BDArtigos", TABLE_NAME = "Artigos";
    private static final String ID="id", REFERENCIA="referencia", PRECO="preco", STOCK="stock", DESCRICAO="descricao", CATEGORIA="categoria_id", IVA="ivas_id", IMAGEM="imagem";
    public static final int DB_VERSION = 1;
    private SQLiteDatabase db;

    public ArtigosDBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        db=getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + " (" +
                ID + " INTEGER PRIMARY KEY, "+
                REFERENCIA + " TEXT NOT NULL, "+
                DESCRICAO + " TEXT NOT NULL, "+
                PRECO + " FLOAT NOT NULL, "+
                STOCK + " INTEGER NOT NULL, "+
                CATEGORIA + " INTEGER NOT NULL, "+
                IVA + " INTEGER NOT NULL, "+
                IMAGEM + " TEXT NOT NULL) ");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    //region CRUD
    public Artigo adicionarArtigoBD(Artigo artigo){
        ContentValues values=new ContentValues();
        values.put(ID, artigo.getId());
        values.put(REFERENCIA, artigo.getReferencia());
        values.put(DESCRICAO, artigo.getDescricao());
        values.put(PRECO, artigo.getPrecoUni());
        values.put(STOCK, artigo.getStock());
        values.put(CATEGORIA, artigo.getCategoriaId());
        values.put(IVA, artigo.getIvasId());
        values.put(IMAGEM, artigo.getImagem());
        db.insert(TABLE_NAME, null, values);
        return artigo;
    }

    public boolean editarArtigoBD(Artigo artigo){
        ContentValues values=new ContentValues();
        values.put(ID, artigo.getId());
        values.put(REFERENCIA, artigo.getReferencia());
        values.put(DESCRICAO, artigo.getDescricao());
        values.put(PRECO, artigo.getPrecoUni());
        values.put(STOCK, artigo.getStock());
        values.put(CATEGORIA, artigo.getCategoriaId());
        values.put(IVA, artigo.getIvasId());
        values.put(IMAGEM, artigo.getImagem());
        int nLinhasEditadas= db.update(TABLE_NAME, values, ID+"=?",new String[] {artigo.getId()+""});
        return nLinhasEditadas>0;
    }

    public boolean removerArtigoBD(int idArtigo){
        int nLinhasDel= db.delete(TABLE_NAME, ID+"=?",new String[] {idArtigo+""});
        return nLinhasDel>0;
    }

    public void removerAllArtigosBD(){
        db.delete(TABLE_NAME, null, null);
    }

    public ArrayList<Artigo> getAllArtigosBD(){
        ArrayList<Artigo> artigos = new ArrayList<>();

        Cursor cursor=db.query(TABLE_NAME, new String[]{ID, REFERENCIA, PRECO, STOCK, CATEGORIA, IVA, DESCRICAO, IMAGEM},
                null,null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Artigo auxArtigo = new Artigo(
                        cursor.getInt(0),          // ID
                        cursor.getFloat(2),        // Preço
                        cursor.getFloat(3),        // Preço Final
                        cursor.getInt(4),          // Stock
                        cursor.getInt(5),          // Categoria ID
                        cursor.getInt(6),          // IVA ID
                        cursor.getInt(7),          // Marca ID
                        cursor.getInt(8),          // Unidade ID
                        cursor.getString(9),       // Nome
                        cursor.getString(10),      // Referência
                        cursor.getString(11),      // Descrição
                        cursor.getString(12),      // Imagem
                        cursor.getInt(13) == 1     // Destaque (assumindo que 1 é verdadeiro e 0 é falso)
                );
                artigos.add(auxArtigo);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return artigos;
    }

    //end region


}
