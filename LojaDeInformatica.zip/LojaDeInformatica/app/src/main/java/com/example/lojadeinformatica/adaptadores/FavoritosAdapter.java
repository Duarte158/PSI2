package com.example.lojadeinformatica.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.lojadeinformatica.R;
import com.example.lojadeinformatica.modelo.Favorito;
import com.squareup.picasso.Picasso;
import java.util.List;

public class FavoritosAdapter extends BaseAdapter {

    private Context context;
    private List<Favorito> favoritos;
    // Defina o caminho base para as imagens
    private static final String CAMINHO_BASE_IMAGENS = "http://localhost/lojadeinformatica/frontend/web/imagens/materiais/";

    public FavoritosAdapter(Context context, List<Favorito> favoritos) {
        this.context = context;
        this.favoritos = favoritos;
    }

    @Override
    public int getCount() {
        return favoritos.size();
    }

    @Override
    public Object getItem(int position) {
        return favoritos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return favoritos.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_favoritos, parent, false);
            holder = new ViewHolder();
            holder.titulo = convertView.findViewById(R.id.titulo);
            holder.descricao = convertView.findViewById(R.id.descricao);
            holder.imagem = convertView.findViewById(R.id.imagem);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Favorito favorito = favoritos.get(position);

        holder.titulo.setText(favorito.getNome());
        holder.descricao.setText(favorito.getDescricao());

        // Concatena o caminho base com o nome da imagem para formar o URL completo
        String urlCompleta = CAMINHO_BASE_IMAGENS + favorito.getImagem();

        // Usa Picasso para carregar a imagem
        Picasso.get()
                .load(urlCompleta)
                .placeholder(R.drawable.ic_placeholder)
                .error(R.drawable.ic_erro_image)
                .into(holder.imagem);

        return convertView;
    }

    static class ViewHolder {
        TextView titulo;
        TextView descricao;
        ImageView imagem;
    }
}
